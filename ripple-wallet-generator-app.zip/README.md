# Ripple Wallet Generator Desktop Application

Electron wrap around Ripple Wallet Generator[Ripple Wallet Generator](https://github.com/unusec/ripple-wallet-generator.git), made available for Windows and Mac.


### Download and install

[Windows]()
[Mac]()


## Donations

Much appreciate it and only if you feel like it, you can donate XRP to this address:

```
rUXmS2w8dbwA98yAws36k1Y4E7XkzvkfwE
```


## Authors

* **UnuSec** - [Twitter](https://twitter.com/UnuSec)


## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details